import React, {Component} from 'react';
import { View, StyleSheet} from 'react-native';


export default class Container extends Component {

    render(){
        return(     
            
            <View style={styles.container}>

            </View>
        
        )
    }

}

const styles = StyleSheet.create({

    container:{
        paddingLeft: 25,
        paddingRight: 25,
    },
   
  });
  



