
package model;

public class PeriodoRepeticao {
    
}
